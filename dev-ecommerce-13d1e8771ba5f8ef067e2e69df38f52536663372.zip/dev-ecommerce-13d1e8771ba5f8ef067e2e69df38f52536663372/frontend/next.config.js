module.exports = {
  reactStrictMode: true,
};
